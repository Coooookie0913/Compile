package FrontEnd.Visitor;

public class Symbol {
    String name;
    SymbolType type;
    
    public Symbol() {
    
    }
    
    public String getName() {
        return name;
    }
    
    public SymbolType getType() {
        return type;
    }
}
