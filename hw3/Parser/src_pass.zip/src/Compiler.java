import FrontEnd.Lexer.Input;
import FrontEnd.Lexer.Lexer;
import FrontEnd.Lexer.TokenStream;
import FrontEnd.Parser.Node;
import FrontEnd.Parser.Parser;
import FrontEnd.Parser.TokenNode;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;

public class Compiler {
    public static void main(String[] args) throws IOException {
        Input input = new Input("testfile.txt");
        InputStream source = input.getInput();
        Lexer lexer = new Lexer(source);
        TokenStream tokenStream = new TokenStream(lexer.getTokenArrayList());
        Parser parser = new Parser(tokenStream);
        Node root = parser.parseCompUnit();
        PrintStream ps = new PrintStream("output.txt");
        System.setOut(ps);
        visitNode(root);
    }
    
    private static void visitNode(Node node) {
        if (node instanceof TokenNode) {
            System.out.println(((TokenNode) node).getToken().getType() + " " + ((TokenNode) node).getToken().getContent());
        } else {
            for (int i = 0; i < node.getChildren().size(); i++) {
                visitNode(node.getChildren().get(i));
            }
            System.out.println("<" + node.getSynName() + ">");
        }
    }
}
