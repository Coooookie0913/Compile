package BackEnd.assembly;

public class GlobalAsm extends Assembly{
}
