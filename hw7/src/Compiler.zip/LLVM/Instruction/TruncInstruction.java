package LLVM.Instruction;

public class TruncInstruction {
}
