package LLVM;

public class Constant extends Value{
    public Constant(LLVMType llvmType, String name) {
        super(llvmType, name);
        int c = Integer.parseInt(name);
    }
}
