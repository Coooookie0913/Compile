package LLVM.Instruction;

public enum IcmpOp {
    EQ,
    NE,
    SGT,
    SGE,
    SLT,
    SLE
}
