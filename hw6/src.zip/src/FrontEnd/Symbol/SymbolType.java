package FrontEnd.Symbol;

public enum SymbolType {
    func,//函数
    con,//常量
    var//变量
}
