package BackEnd.assembly;

public class SyscallAsm extends Assembly{
    public String toString() {
        return "syscall";
    }
}
